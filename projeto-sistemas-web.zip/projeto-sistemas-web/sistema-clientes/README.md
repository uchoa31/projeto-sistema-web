
# Sistema de Cadastro de Clientes

## 1. Identificação do Projeto

- Nome: Sistema de Cadastro de Clientes
- Desenvolvedores: [Inserir nomes]
- Curso: [Inserir curso]
- Disciplina: [Inserir disciplina]
- Professor: [Inserir nome]
- Data: [Inserir data]

## 2. Introdução

O Sistema de Cadastro de Clientes é uma aplicação Web
desenvolvida para facilitar o registro, a consulta e o
gerenciamento das informações dos clientes de uma empresa.

## 3. Objetivo do Sistema

O objetivo é permitir que pequenas empresas organizem
seus cadastros de clientes de maneira simples e eficiente.

## 4. Tecnologias Utilizadas

- HTML5: estrutura da aplicação e formulário.
- CSS3: estilização e responsividade.
- JavaScript: validações, cadastro, pesquisa e exclusão.
- LocalStorage: armazenamento dos registros no navegador.

## 5. Requisitos Funcionais

- Cadastrar clientes.
- Validar os campos.
- Validar CPF.
- Listar clientes.
- Pesquisar clientes.
- Excluir clientes.
- Armazenar os dados no navegador.

## 6. Requisitos Não Funcionais

- Interface intuitiva.
- Layout responsivo.
- Compatibilidade com navegadores modernos.
- Organização do código.
- Facilidade de utilização.

## 7. Estrutura dos Arquivos

sistema-clientes/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── script.js
└── README.md

## 8. Capturas de Tela

Adicionar imagens da tela inicial, cadastro, listagem
e testes do sistema nesta seção.

## 9. Como Executar

1. Baixe ou clone o repositório.
2. Abra a pasta sistema-clientes.
3. Abra o arquivo index.html no navegador.
4. Utilize o formulário para cadastrar clientes.

## 10. Conclusão

O desenvolvimento permitiu aplicar conhecimentos
de HTML5, CSS3 e JavaScript na criação de uma aplicação
Web funcional, com validação de dados e armazenamento
local utilizando LocalStorage.
