
const form = document.getElementById("formCliente");

const listaClientes = document.getElementById("listaClientes");
const totalClientes = document.getElementById("totalClientes");
const mensagemVazia = document.getElementById("mensagemVazia");
const pesquisa = document.getElementById("pesquisa");

let clientes = JSON.parse(
    localStorage.getItem("clientes")
) || [];

// SALVAR NO LOCALSTORAGE

function salvarDados() {
    localStorage.setItem(
        "clientes",
        JSON.stringify(clientes)
    );
}

// VALIDAR CPF

function validarCPF(cpf) {
    cpf = cpf.replace(/\D/g, "");

    if (cpf.length !== 11 || /^(\d)\1{10}$/.test(cpf)) {
        return false;
    }

    let soma = 0;

    for (let i = 0; i < 9; i++) {
        soma += Number(cpf[i]) * (10 - i);
    }

    let resto = (soma * 10) % 11;

    if (resto === 10) resto = 0;

    if (resto !== Number(cpf[9])) {
        return false;
    }

    soma = 0;

    for (let i = 0; i < 10; i++) {
        soma += Number(cpf[i]) * (11 - i);
    }

    resto = (soma * 10) % 11;

    if (resto === 10) resto = 0;

    return resto === Number(cpf[10]);
}

// FORMATAR CPF

function formatarCPF(valor) {
    return valor
        .replace(/\D/g, "")
        .slice(0, 11)
        .replace(/(\d{3})(\d)/, "$1.$2")
        .replace(/(\d{3})(\d)/, "$1.$2")
        .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
}

// FORMATAR TELEFONE

function formatarTelefone(valor) {
    const numeros = valor.replace(/\D/g, "").slice(0, 11);

    if (numeros.length <= 10) {
        return numeros
            .replace(/(\d{2})(\d)/, "($1) $2")
            .replace(/(\d{4})(\d)/, "$1-$2");
    }

    return numeros
        .replace(/(\d{2})(\d)/, "($1) $2")
        .replace(/(\d{5})(\d)/, "$1-$2");
}

// MÁSCARAS

document.getElementById("cpf").addEventListener("input", function() {
    this.value = formatarCPF(this.value);
});

document.getElementById("telefone").addEventListener("input", function() {
    this.value = formatarTelefone(this.value);
});

// CADASTRAR CLIENTE

form.addEventListener("submit", function(event) {
    event.preventDefault();

    const nome = document.getElementById("nome").value.trim();
    const cpf = document.getElementById("cpf").value;
    const telefone = document.getElementById("telefone").value;
    const email = document.getElementById("email").value.trim();
    const endereco = document.getElementById("endereco").value.trim();

    if (nome.length < 3) {
        alert("Digite um nome válido.");
        return;
    }

    if (!validarCPF(cpf)) {
        alert("CPF inválido. Verifique os números.");
        return;
    }

    if (telefone.replace(/\D/g, "").length < 10) {
        alert("Digite um telefone válido.");
        return;
    }

    const emailValido = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailValido.test(email)) {
        alert("Digite um e-mail válido.");
        return;
    }

    if (endereco.length < 5) {
        alert("Digite um endereço válido.");
        return;
    }

    const cpfLimpo = cpf.replace(/\D/g, "");

    const cpfExiste = clientes.some(
        cliente => cliente.cpf.replace(/\D/g, "") === cpfLimpo
    );

    if (cpfExiste) {
        alert("Este CPF já está cadastrado.");
        return;
    }

    const cliente = {
        id: Date.now(),
        nome,
        cpf,
        telefone,
        email,
        endereco
    };

    clientes.push(cliente);

    salvarDados();
    renderizarClientes();

    form.reset();

    alert("Cliente cadastrado com sucesso!");
});

// EXCLUIR CLIENTE

function excluirCliente(id) {
    const confirmar = confirm(
        "Deseja realmente excluir este cliente?"
    );

    if (!confirmar) return;

    clientes = clientes.filter(
        cliente => cliente.id !== id
    );

    salvarDados();
    renderizarClientes();
}

// MOSTRAR CLIENTES

function renderizarClientes() {
    listaClientes.innerHTML = "";

    const termo = pesquisa.value.toLowerCase();

    const filtrados = clientes.filter(cliente =>
        cliente.nome.toLowerCase().includes(termo) ||
        cliente.cpf.includes(termo)
    );

    totalClientes.textContent = clientes.length;

    mensagemVazia.style.display =
        filtrados.length === 0 ? "block" : "none";

    filtrados.forEach(cliente => {
        const linha = document.createElement("tr");

        const valores = [
            cliente.nome,
            cliente.cpf,
            cliente.telefone,
            cliente.email,
            cliente.endereco
        ];

        valores.forEach(valor => {
            const coluna = document.createElement("td");
            coluna.textContent = valor;
            linha.appendChild(coluna);
        });

        const colunaAcao = document.createElement("td");

        const botao = document.createElement("button");
        botao.textContent = "Excluir";
        botao.className = "btn-delete";

        botao.addEventListener("click", () => {
            excluirCliente(cliente.id);
        });

        colunaAcao.appendChild(botao);
        linha.appendChild(colunaAcao);

        listaClientes.appendChild(linha);
    });
}

// PESQUISAR CLIENTES

pesquisa.addEventListener("input", renderizarClientes);

// INICIALIZAR SISTEMA

renderizarClientes();
