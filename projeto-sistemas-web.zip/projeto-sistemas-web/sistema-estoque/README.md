
# Sistema de Controle de Estoque

## 1. Identificação do Projeto

- Nome: Sistema de Controle de Estoque
- Desenvolvedores: [Inserir nomes]
- Curso: [Inserir curso]
- Disciplina: [Inserir disciplina]
- Professor: [Inserir nome]
- Data: [Inserir data]

## 2. Introdução

O sistema foi desenvolvido para facilitar o controle
dos produtos de uma pequena empresa, permitindo
acompanhar quantidades e valores em estoque.

## 3. Objetivo do Sistema

Organizar os produtos cadastrados, calcular o valor
total do estoque e identificar produtos com baixa
quantidade.

## 4. Tecnologias Utilizadas

- HTML5: estrutura da página.
- CSS3: aparência e organização visual.
- JavaScript: cálculos, validações e funcionalidades.
- LocalStorage: armazenamento dos produtos.

## 5. Requisitos Funcionais

- Cadastrar produtos.
- Informar nome, código, quantidade e preço.
- Listar produtos.
- Pesquisar produtos.
- Calcular valor total do estoque.
- Identificar estoque baixo.
- Excluir produtos.

## 6. Requisitos Não Funcionais

- Interface simples.
- Layout responsivo.
- Compatibilidade com navegadores modernos.
- Facilidade de utilização.

## 7. Estrutura dos Arquivos

sistema-estoque/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── script.js
└── README.md

## 8. Capturas de Tela

Adicionar imagens do cadastro, listagem e resultados
dos testes realizados.

## 9. Como Executar

1. Abra a pasta sistema-estoque.
2. Abra o arquivo index.html no navegador.
3. Cadastre os produtos para começar a utilizar.

## 10. Conclusão

O projeto permitiu aplicar conhecimentos de HTML,
CSS e JavaScript na criação de um sistema de controle
de estoque, utilizando cálculos automáticos e
armazenamento local.
