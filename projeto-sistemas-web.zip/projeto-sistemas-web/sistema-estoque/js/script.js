
const form = document.getElementById("formProduto");
const lista = document.getElementById("listaProdutos");

const totalProdutos = document.getElementById("totalProdutos");
const valorEstoque = document.getElementById("valorEstoque");
const estoqueBaixo = document.getElementById("estoqueBaixo");

const pesquisa = document.getElementById("pesquisa");
const mensagemVazia = document.getElementById("mensagemVazia");

let produtos = JSON.parse(
    localStorage.getItem("produtos")
) || [];

function salvarProdutos() {
    localStorage.setItem(
        "produtos",
        JSON.stringify(produtos)
    );
}

function dinheiro(valor) {
    return valor.toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
}

// CADASTRAR PRODUTO

form.addEventListener("submit", function(event) {
    event.preventDefault();

    const nome = document.getElementById("nome").value.trim();
    const codigo = document.getElementById("codigo").value.trim();
    const quantidade = Number(document.getElementById("quantidade").value);
    const preco = Number(document.getElementById("preco").value);

    if (nome.length < 2 || codigo.length < 1) {
        alert("Informe um nome e código válidos.");
        return;
    }

    if (!Number.isInteger(quantidade) || quantidade < 0) {
        alert("A quantidade deve ser um número inteiro igual ou maior que zero.");
        return;
    }

    if (!Number.isFinite(preco) || preco <= 0) {
        alert("Informe um preço maior que zero.");
        return;
    }

    const codigoExiste = produtos.some(
        produto => produto.codigo.toLowerCase() === codigo.toLowerCase()
    );

    if (codigoExiste) {
        alert("Este código já está cadastrado.");
        return;
    }

    const produto = {
        id: Date.now(),
        nome,
        codigo,
        quantidade,
        preco
    };

    produtos.push(produto);

    salvarProdutos();
    mostrarProdutos();

    form.reset();

    alert("Produto cadastrado com sucesso!");
});

// EXCLUIR PRODUTO

function excluirProduto(id) {
    if (!confirm("Deseja excluir este produto?")) {
        return;
    }

    produtos = produtos.filter(
        produto => produto.id !== id
    );

    salvarProdutos();
    mostrarProdutos();
}

// MOSTRAR PRODUTOS

function mostrarProdutos() {
    lista.innerHTML = "";

    const termo = pesquisa.value.toLowerCase();

    const filtrados = produtos.filter(produto =>
        produto.nome.toLowerCase().includes(termo) ||
        produto.codigo.toLowerCase().includes(termo)
    );

    const total = produtos.reduce(
        (soma, produto) => soma + produto.quantidade * produto.preco,
        0
    );

    const quantidadeBaixa = produtos.filter(
        produto => produto.quantidade < 5
    ).length;

    totalProdutos.textContent = produtos.length;
    valorEstoque.textContent = dinheiro(total);
    estoqueBaixo.textContent = quantidadeBaixa;

    mensagemVazia.style.display =
        filtrados.length === 0 ? "block" : "none";

    filtrados.forEach(produto => {
        const linha = document.createElement("tr");

        const valores = [
            produto.nome,
            produto.codigo,
            produto.quantidade,
            dinheiro(produto.preco),
            dinheiro(produto.quantidade * produto.preco)
        ];

        valores.forEach(valor => {
            const coluna = document.createElement("td");
            coluna.textContent = valor;
            linha.appendChild(coluna);
        });

        const colunaStatus = document.createElement("td");

        if (produto.quantidade < 5) {
            colunaStatus.textContent = "Estoque baixo";
            colunaStatus.className = "status-baixo";
        } else {
            colunaStatus.textContent = "Normal";
            colunaStatus.className = "status-normal";
        }

        linha.appendChild(colunaStatus);

        const colunaAcao = document.createElement("td");
        const botao = document.createElement("button");

        botao.textContent = "Excluir";
        botao.className = "btn-delete";

        botao.addEventListener("click", () => {
            excluirProduto(produto.id);
        });

        colunaAcao.appendChild(botao);
        linha.appendChild(colunaAcao);

        lista.appendChild(linha);
    });
}

pesquisa.addEventListener("input", mostrarProdutos);

// INICIAR SISTEMA

mostrarProdutos();
