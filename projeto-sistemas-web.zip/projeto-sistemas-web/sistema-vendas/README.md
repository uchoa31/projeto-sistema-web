
# Sistema de Vendas

## 1. Identificação do Projeto

- Nome: Sistema de Vendas
- Desenvolvedores: [Inserir nomes]
- Curso: [Inserir curso]
- Disciplina: [Inserir disciplina]
- Professor: [Inserir nome]
- Data: [Inserir data]

## 2. Introdução

O Sistema de Vendas foi desenvolvido para simular
o processo de venda de produtos de uma pequena loja.

## 3. Objetivo do Sistema

Permitir selecionar produtos, informar quantidades,
calcular valores, aplicar descontos e registrar
as vendas realizadas.

## 4. Tecnologias Utilizadas

- HTML5: estrutura da aplicação.
- CSS3: aparência e organização da página.
- JavaScript: cálculos, validações e registro das vendas.
- LocalStorage: armazenamento dos dados no navegador.

## 5. Requisitos Funcionais

- Selecionar produtos cadastrados no estoque.
- Informar quantidade.
- Calcular subtotal.
- Aplicar desconto.
- Calcular valor final.
- Exibir resumo da venda.
- Finalizar venda.
- Atualizar quantidade no estoque.
- Registrar histórico de vendas.

## 6. Requisitos Não Funcionais

- Interface simples e organizada.
- Layout responsivo.
- Facilidade de utilização.
- Compatibilidade com navegadores modernos.

## 7. Estrutura dos Arquivos

sistema-vendas/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── script.js
└── README.md

## 8. Capturas de Tela

Adicionar imagens da tela de vendas, resumo,
finalização e histórico.

## 9. Como Executar

1. Abra a pasta sistema-vendas.
2. Abra o arquivo index.html no navegador.
3. Cadastre produtos primeiro no Sistema de Estoque.
4. Selecione um produto.
5. Informe a quantidade e o desconto.
6. Calcule e finalize a venda.

## 10. Conclusão

O desenvolvimento possibilitou aplicar conhecimentos
de programação Web, utilizando HTML, CSS e JavaScript
para criar uma aplicação de vendas com cálculos,
validações e integração com o controle de estoque.
