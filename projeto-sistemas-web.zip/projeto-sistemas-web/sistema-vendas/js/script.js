
const form = document.getElementById("formVenda");

const campoProduto = document.getElementById("produto");
const campoQuantidade = document.getElementById("quantidade");
const campoDesconto = document.getElementById("desconto");

const listaVendas = document.getElementById("listaVendas");

let produtos = JSON.parse(
    localStorage.getItem("produtos")
) || [];

let vendas = JSON.parse(
    localStorage.getItem("vendas")
) || [];

let vendaCalculada = null;

// FORMATAR VALORES EM REAIS

function dinheiro(valor) {
    return valor.toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
}

// CARREGAR PRODUTOS DO ESTOQUE

function carregarProdutos() {
    campoProduto.innerHTML =
        '<option value="">Selecione um produto</option>';

    produtos = JSON.parse(
        localStorage.getItem("produtos")
    ) || [];

    produtos.forEach(produto => {
        const opcao = document.createElement("option");

        opcao.value = produto.id;

        opcao.textContent =
            produto.nome +
            " - Estoque: " +
            produto.quantidade;

        campoProduto.appendChild(opcao);
    });
}

// CALCULAR VENDA

function calcularVenda() {
    produtos = JSON.parse(
        localStorage.getItem("produtos")
    ) || [];

    const id = Number(campoProduto.value);

    const produto = produtos.find(
        item => item.id === id
    );

    const quantidade = Number(campoQuantidade.value);
    const desconto = Number(campoDesconto.value);

    if (!produto) {
        alert("Selecione um produto.");
        return false;
    }

    if (!Number.isInteger(quantidade) || quantidade < 1) {
        alert("Informe uma quantidade válida.");
        return false;
    }

    if (quantidade > produto.quantidade) {
        alert("Quantidade maior que o estoque disponível.");
        return false;
    }

    if (
        !Number.isFinite(desconto) ||
        desconto < 0 ||
        desconto > 100
    ) {
        alert("O desconto deve estar entre 0 e 100%.");
        return false;
    }

    const subtotal = produto.preco * quantidade;

    const valorDesconto = subtotal * (desconto / 100);

    const total = subtotal - valorDesconto;

    vendaCalculada = {
        produtoId: produto.id,
        nome: produto.nome,
        preco: produto.preco,
        quantidade,
        desconto,
        subtotal,
        valorDesconto,
        total
    };

    // MOSTRAR RESUMO

    document.getElementById("nomeResumo").textContent =
        produto.nome;

    document.getElementById("precoResumo").textContent =
        dinheiro(produto.preco);

    document.getElementById("quantidadeResumo").textContent =
        quantidade;

    document.getElementById("subtotalResumo").textContent =
        dinheiro(subtotal);

    document.getElementById("descontoResumo").textContent =
        dinheiro(valorDesconto);

    document.getElementById("totalResumo").textContent =
        "Total: " + dinheiro(total);

    return true;
}

// BOTÃO CALCULAR

document.getElementById("calcular").addEventListener(
    "click",
    calcularVenda
);

// ALTEROU OS DADOS? PRECISA CALCULAR NOVAMENTE

campoProduto.addEventListener("change", () => {
    vendaCalculada = null;
});

campoQuantidade.addEventListener("input", () => {
    vendaCalculada = null;
});

campoDesconto.addEventListener("input", () => {
    vendaCalculada = null;
});

// FINALIZAR VENDA

form.addEventListener("submit", function(event) {
    event.preventDefault();

    if (!calcularVenda()) {
        return;
    }

    const produto = produtos.find(
        item => item.id === vendaCalculada.produtoId
    );

    if (!produto || produto.quantidade < vendaCalculada.quantidade) {
        alert("Estoque insuficiente. Confira os produtos.");
        return;
    }

    const confirmar = confirm(
        "Deseja finalizar esta venda?"
    );

    if (!confirmar) {
        return;
    }

    // DIMINUIR QUANTIDADE DO ESTOQUE

    produto.quantidade -= vendaCalculada.quantidade;

    localStorage.setItem(
        "produtos",
        JSON.stringify(produtos)
    );

    // REGISTRAR VENDA

    const novaVenda = {
        id: Date.now(),
        produto: vendaCalculada.nome,
        quantidade: vendaCalculada.quantidade,
        desconto: vendaCalculada.desconto,
        total: vendaCalculada.total,
        data: new Date().toLocaleString("pt-BR")
    };

    vendas.push(novaVenda);

    localStorage.setItem(
        "vendas",
        JSON.stringify(vendas)
    );

    alert("Venda finalizada com sucesso!");

    form.reset();

    document.getElementById("quantidade").value = 1;
    document.getElementById("desconto").value = 0;

    vendaCalculada = null;

    limparResumo();
    carregarProdutos();
    mostrarVendas();
});

// LIMPAR RESUMO

function limparResumo() {
    document.getElementById("nomeResumo").textContent = "-";

    document.getElementById("precoResumo").textContent =
        "R$ 0,00";

    document.getElementById("quantidadeResumo").textContent = "0";

    document.getElementById("subtotalResumo").textContent =
        "R$ 0,00";

    document.getElementById("descontoResumo").textContent =
        "R$ 0,00";

    document.getElementById("totalResumo").textContent =
        "Total: R$ 0,00";
}

// MOSTRAR HISTÓRICO DE VENDAS

function mostrarVendas() {
    listaVendas.innerHTML = "";

    vendas = JSON.parse(
        localStorage.getItem("vendas")
    ) || [];

    const total = vendas.reduce(
        (soma, venda) => soma + venda.total,
        0
    );

    document.getElementById("totalVendas").textContent =
        vendas.length;

    document.getElementById("totalVendido").textContent =
        dinheiro(total);

    document.getElementById("mensagemVazia").style.display =
        vendas.length === 0 ? "block" : "none";

    vendas.forEach(venda => {
        const linha = document.createElement("tr");

        const valores = [
            venda.produto,
            venda.quantidade,
            venda.desconto + "%",
            dinheiro(venda.total),
            venda.data
        ];

        valores.forEach(valor => {
            const coluna = document.createElement("td");

            coluna.textContent = valor;

            linha.appendChild(coluna);
        });

        listaVendas.appendChild(linha);
    });
}

// INICIAR SISTEMA

carregarProdutos();
mostrarVendas();
